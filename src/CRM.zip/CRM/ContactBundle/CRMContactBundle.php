<?php

namespace CRM\ContactBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CRMContactBundle extends Bundle
{
}

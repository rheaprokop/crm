<?php

namespace CRM\SupportBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CRMSupportBundle extends Bundle
{
}

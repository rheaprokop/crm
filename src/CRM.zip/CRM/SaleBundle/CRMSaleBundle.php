<?php

namespace CRM\SaleBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CRMSaleBundle extends Bundle
{
}

<?php

namespace CRM\SiteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CRMSiteBundle extends Bundle
{
}
